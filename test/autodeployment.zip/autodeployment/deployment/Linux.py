import paramiko


# import datetime


class SSHClient(object):

    def __init__(self, host, port, user, password):
        """

        :param host:str
        :param port:int
        :param user:str
        :param password:str
        """
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(hostname=host, port=port, username=user, password=password)

    def makedir(self, path):
        """
        创建多个文件夹
        :param path: str 要创建的文件夹
        :return: True False
        """
        cmd = "mkdir -p " + path
        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        result = std_out.read().decode()
        if result == '':
            return True
        else:
            return False

    def zip(self, from_path, to_path, file_name, zip_name):
        """

        :param from_path: 要备份的文件路径
        :param to_path: 备份到的路径
        :param file_name: 要压缩的文件/文件夹名 * 代表所有
        :param zip_name: 压缩后名称 now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        :return:
        """

        cmd = "cd " + from_path + " && " + "zip " + to_path + zip_name + ".zip " + file_name
        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        result = std_out.read().decode()
        if result.find('error') == -1:
            return True
        else:
            return False

    def unzip(self, file, to_path):
        """

        :param file: 要解压的文件 (包含目录)
        :param to_path: 解压位置
        :return:
        """

        cmd = "unzip " + file + " -d " + to_path
        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        result = std_out.read().decode()
        if result.find('Archive') == -1:
            return False
        else:
            return True

    def remove(self, path, file_name):
        """

        :param path:要删除文件的路径
        :param file_name:要删除文件的名称，'*'代表删除所有
        :return:
        """
        if file_name == '*':
            cmd = "rm -rf " + path + file_name
        elif file_name is None:
            cmd = "rm -rf " + path
        else:
            cmd = "rm -f " + path + file_name

        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        result = std_out.read().decode()
        if result == '':
            return True
        else:
            return False

    def run_shell_file(self, path, file_name):
        """
        :param path: 文件路径
        :param file_name: 文件名
        :return:
        """
        cmd = "cd %s && sh %s" % (path, file_name)
        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        # result = std_out.read().decode()

        if len(std_err.read().decode()) == 0:
            return True
        else:
            return False

    def get_file_name(self, path):
        cmd = 'ls %s' % path
        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        result = std_out.read().decode().split('\n')
        file_list = [file for file in result if file != '']
        return file_list

    def get_pid_list(self, process_name):
        # cmd = 'ps -ef | grep %s' % process_name
        cmd = 'pgrep -f %s' % process_name
        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        result = std_out.read().decode().split('\n')
        pid_list = [pid for pid in result if pid != '']
        return pid_list

    def kill(self, pid):
        """

        :param pid: str 根据pid杀掉进程
        :return:
        """
        cmd = "kill -9 " + pid
        std_in, std_out, std_err = self.ssh.exec_command(cmd)
        result = std_out.read().decode()
        if result == '':
            return True
        else:
            return False

    def ssh_close(self):
        self.ssh.close()


class Transport(object):
    def __init__(self, host, port, user, password):
        """

        :param host:str
        :param port:int
        :param user:str
        :param password:str
        """
        self.transport = paramiko.Transport(host, port)
        self.transport.connect(username=user, password=password)

    def sftp(self, local_path, remote_path):
        sftp = paramiko.SFTPClient.from_transport(self.transport)
        sftp.put(local_path, remote_path)

    def transport_close(self):
        self.transport.close()


if __name__ == '__main__':
    local_host = '192.168.182.130'
    local_port = 22
    local_user = 'root'
    local_password = '123456'
    ssh = SSHClient(local_host, local_port, local_user, local_password)
    files_list = ssh.get_file_name('/mysite/')
    print(files_list)
    # print(results)
    # for item in results:
    #     if item:
    #         print(item)
    ssh.ssh_close()

    # transport = Transport(local_host, local_port, local_user, local_password)
    # transport.sftp('../uploads/test.zip', '/myfile/test.zip')
    # transport.transport_close()
