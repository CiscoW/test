import datetime

from deployment.Linux import SSHClient
from deployment.Linux import Transport


class DeployServer(object):
    def __init__(self, server_ip, server_port, server_user, server_password):
        self.server_ip = server_ip
        self.server_port = server_port
        self.server_user = server_user
        self.server_password = server_password
        self.ssh_client = False
        self.transport = False

    def connect_ssh_client(self):
        """

        :return: ssh_client 连接失败时值为False
        """
        try:
            self.ssh_client = SSHClient(self.server_ip, self.server_port, self.server_user, self.server_password)
        except TimeoutError:
            pass

        return self.ssh_client

    def close_ssh_client(self):
        if self.ssh_client:
            self.ssh_client.ssh_close()

    def makedir(self, directory):
        """

        :param directory: str 要创建的文件夹
        :return:
        """
        makedir_result = self.ssh_client.makedir(directory)
        return makedir_result

    def file_backup(self, file_directory, bak_directory, file_name, bak_name):
        """

        :param file_directory: 文件路径
        :param bak_directory: 备份路径
        :param file_name: 要备份的文件名 '*' 代表全部
        :param bak_name: 备份文件名
        :return: True False 成功 or 失败
        """
        bak_result = self.ssh_client.zip(file_directory, bak_directory, file_name=file_name, zip_name=bak_name)
        return bak_result

    def file_delete(self, file_directory, file_name):
        """

        :param file_directory:要删除的文件路径
        :param file_name:要删除的文件名 '*' 代表删除所有
        :return:
        """
        delete_result = self.ssh_client.remove(file_directory, file_name=file_name)
        return delete_result

    def file_unzip(self, file, unzip_directory):
        """

        :param file: 要解压的文件 包含路径
        :param unzip_directory: 解压到的目录
        :return:
        """
        unzip_result = self.ssh_client.unzip(file, unzip_directory)
        return unzip_result

    def get_file_list(self, directory):
        file_list = self.ssh_client.get_file_name(directory)
        return file_list

    def get_pid_list(self, process_name):
        pid_list = self.ssh_client.get_pid_list(process_name)
        return pid_list

    def kill_process(self, pid):
        kill_result = self.ssh_client.kill(pid)
        return kill_result

    def execute_sh_file(self, directory, file_name):
        execute_result = self.ssh_client.run_shell_file(directory, file_name)
        return execute_result

    def connect_transport(self):
        try:
            self.transport = Transport(self.server_ip, self.server_port, self.server_user, self.server_password)
        except TimeoutError:
            pass
        return self.transport

    def sftp(self, local_file, remote_path):
        self.transport.sftp(local_file, remote_path)

    def close_transport(self):
        if self.transport:
            self.transport.transport_close()

    def deploy_web_server(self, service_directory, bak_directory, upload_file, upload_file_name):
        file_name = '*'
        bak_name = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        remote_path = service_directory + upload_file_name
        bak_file = ''

        self.connect_ssh_client()
        if not self.ssh_client:
            remark = '连接不上服务器'
            return remark, bak_file

        # 不管文件夹有没有都创建下
        self.makedir(service_directory)
        self.makedir(bak_directory)

        # 第二次部署时，传入的bak_directory为空时说明不用备份
        if bak_directory:
            bak_result = self.file_backup(service_directory, bak_directory, file_name, bak_name)
            if not bak_result:
                """文件备份失败 说明文件夹是空的"""
                bak_file = ''
            else:
                bak_file = bak_directory + bak_name

        delete_result = self.file_delete(service_directory, file_name)
        if not delete_result:
            remark = '服务文件删除失败'
            self.close_ssh_client()
            return remark, bak_file

        self.connect_transport()
        if not self.transport:
            remark = '向服务器发送文件失败'
            self.close_ssh_client()
            return remark, bak_file
        self.sftp(upload_file, remote_path)
        self.close_transport()

        unzip_result = self.file_unzip(remote_path, service_directory)
        if not unzip_result:
            remark = '文件解压失败'
            self.close_ssh_client()
            return remark, bak_file

        self.file_delete(service_directory, upload_file_name)
        self.close_ssh_client()
        remark = '部署完成'
        return remark, bak_file

    def deploy_service_server(self, service_directory, bak_directory, upload_file, upload_file_name):
        file_name = '*'
        bak_name = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        suffix = upload_file_name[upload_file_name.rfind('.') + 1:]
        remote_path = service_directory + upload_file_name
        bak_file = ''

        self.connect_ssh_client()
        if not self.ssh_client:
            remark = '连接不上服务器'
            return remark, bak_file

        # 不管文件夹有没有都创建下
        self.makedir(service_directory)
        self.makedir(bak_directory)
        # 创建deploying文件夹用于判断当前是否在部署状态
        self.makedir(service_directory + 'deploying/')

        file_list = self.get_file_list(service_directory)
        for file in file_list:
            if file[file.rfind('.') + 1:] == 'jar':
                pid_list = self.get_pid_list(file)
                if len(pid_list) > 0:
                    for pid in pid_list:
                        kill_result = self.kill_process(pid)
                        if not kill_result:
                            remark = '进程结束失败！'
                            self.file_delete(service_directory + 'deploying/', file_name=None)
                            self.close_ssh_client()
                            return remark, bak_file

        # 第二次部署时，传入的bak_directory为空时说明不用备份
        if bak_directory:
            bak_result = self.file_backup(service_directory, bak_directory, file_name, bak_name)
            if not bak_result:
                """文件备份失败 说明文件夹是空的"""
                bak_file = ''
            else:
                bak_file = bak_directory + bak_name

        if suffix == 'jar':
            file_name = upload_file_name
        delete_result = self.file_delete(service_directory, file_name)
        if not delete_result:
            remark = '服务文件删除失败'
            self.file_delete(service_directory + 'deploying/', file_name=None)
            self.close_ssh_client()
            return remark, bak_file

        self.connect_transport()
        if not self.transport:
            remark = '向服务器发送文件失败'
            self.file_delete(service_directory + 'deploying/', file_name=None)
            self.close_ssh_client()
            return remark, bak_file
        self.sftp(upload_file, remote_path)
        self.close_transport()
        if suffix != 'jar':
            unzip_result = self.file_unzip(remote_path, service_directory)
            if not unzip_result:
                remark = '文件解压失败'
                self.file_delete(service_directory + 'deploying/', file_name=None)
                self.close_ssh_client()
                return remark, bak_file
            self.file_delete(service_directory, upload_file_name)
        execute_result = self.execute_sh_file(service_directory, 'run.sh')
        if not execute_result:
            remark = 'run.sh 文件执行失败'
            self.file_delete(service_directory + 'deploying/', file_name=None)
            return remark, bak_file

        self.file_delete(service_directory + 'deploying/', file_name=None)
        self.close_ssh_client()
        remark = '部署完成'
        return remark, bak_file

    def rollback_web_server(self, service_directory, bak_file):
        if not bak_file:
            remark = '未找到备份文件'
            return remark

        self.connect_ssh_client()
        if not self.ssh_client:
            remark = '连接不上服务器'
            return remark

        delete_result = self.file_delete(service_directory, '*')
        if not delete_result:
            remark = '服务文件删除失败'
            self.close_ssh_client()
            return remark

        unzip_result = self.file_unzip(bak_file, service_directory)
        if not unzip_result:
            remark = '备份文件解压失败'
            self.close_ssh_client()
            return remark

        remark = '回滚完成'
        return remark

    def rollback_service_server(self, service_directory, bak_file):
        if not bak_file:
            remark = '未找到备份文件'
            return remark

        self.connect_ssh_client()
        if not self.ssh_client:
            remark = '连接不上服务器'
            return remark

        # 创建deploying文件夹用于判断当前是否在部署状态
        self.makedir(service_directory + 'deploying/')

        file_list = self.get_file_list(service_directory)
        for file in file_list:
            if file[file.rfind('.') + 1:] == 'jar':
                pid_list = self.get_pid_list(file)
                if len(pid_list) > 0:
                    for pid in pid_list:
                        kill_result = self.kill_process(pid)
                        if not kill_result:
                            remark = '进程结束失败！'
                            self.file_delete(service_directory + 'deploying/', file_name=None)
                            self.close_ssh_client()
                            return remark

        delete_result = self.file_delete(service_directory, '*')
        if not delete_result:
            remark = '服务文件删除失败'
            self.file_delete(service_directory + 'deploying/', file_name=None)
            self.close_ssh_client()
            return remark

        unzip_result = self.file_unzip(bak_file, service_directory)
        if not unzip_result:
            remark = '备份文件解压失败'
            self.file_delete(service_directory + 'deploying/', file_name=None)
            self.close_ssh_client()
            return remark

        execute_result = self.execute_sh_file(service_directory, 'run.sh')
        if not execute_result:
            remark = 'run.sh 文件执行失败'
            self.file_delete(service_directory + 'deploying/', file_name=None)
            return remark

        self.file_delete(service_directory + 'deploying/', file_name=None)
        self.close_ssh_client()
        remark = '回滚完成'
        return remark
