import uuid
import datetime
from django.db import models
from django.core.exceptions import ValidationError
from server_data.models import AppList
from server_data.AES import AesField


def get_uuid1():
    return str(uuid.uuid1()).replace('-', '')


def upload_path(instance, filename):
    now = datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")
    upload_dir = 'uploads/' + now + '/' + filename
    return upload_dir


_DEPLOY_TYPE = (
    ('部署', '部署'),
    ('回滚', '回滚'),
)


# Create your models here.


class DeployMainTable(models.Model):
    deploy_id = models.CharField('id', max_length=32, primary_key=True, default=get_uuid1)
    deploy_date = models.DateField('部署日期')
    deploy_version = models.CharField('版本', max_length=100)
    deploy_type = models.CharField('操作', max_length=100, choices=_DEPLOY_TYPE, default='部署')
    deploy_app = models.ForeignKey(AppList, verbose_name='部署应用', limit_choices_to={'status': True},
                                   on_delete=models.PROTECT)
    deploy_file = models.FileField('部署文件(*.zip *.jar)', upload_to=upload_path, blank=True)
    remark = models.TextField('备注', max_length=500, blank=True)

    Creator = models.CharField(u'创建者', max_length=100, editable=False, blank=True)
    CreateTime = models.DateTimeField(u'创建时间', auto_now_add=True, editable=False, blank=True)
    LastUpdateUser = models.CharField(u'最后修改者', max_length=100, editable=False, blank=True)
    LastUpdateTime = models.DateTimeField(u'最后修改时间', auto_now=True, editable=False, blank=True)

    def clean(self):
        try:
            self.deploy_app
        except Exception:
            raise ValidationError({'deploy_app': '请选择要部署的应用！'})

        if self.deploy_type == '部署' and self.deploy_file == '':
            raise ValidationError({'deploy_file': '部署时，上传文件不能为空！'})

        if self.deploy_type == '部署' and str(self.deploy_file)[-3:] not in ['zip', 'jar']:
            raise ValidationError({'deploy_file': '上传文件只能为zip或jar格式！'})

        servers_name = DeploySubTable.objects.values('server_name').filter(deploy_sub_table_id=self.deploy_id)
        if len(servers_name) == 0 and self.deploy_type == '回滚':
            raise ValidationError({'deploy_type': '当前无法进行回滚操作！'})

        version_list = DeployMainTable.objects.values('deploy_version').filter(deploy_version=self.deploy_version,
                                                                               deploy_app=self.deploy_app
                                                                               ).exclude(deploy_id=self.deploy_id)
        if len(version_list) != 0:
            raise ValidationError({'deploy_version': '当前版本已经存在！'})

    def __str__(self):
        return ''

    class Meta:
        verbose_name_plural = verbose_name = "应用部署"


class DeploySubTable(models.Model):
    deploy_sub_table_id = models.ForeignKey(DeployMainTable, on_delete=models.CASCADE)
    server_name = models.CharField('服务器 名称', max_length=100, blank=True)
    server_ip = models.CharField('ip', max_length=100, blank=True)
    server_port = models.CharField('端口', max_length=100, blank=True)
    server_user = AesField('用户名', max_length=500, blank=True, editable=False)
    server_password = AesField('密码', max_length=500, blank=True, editable=False)
    server_directory = models.CharField('服务目录', max_length=100, blank=True)
    server_bak_directory = models.CharField('备份目录', max_length=100, blank=True)
    status = models.BooleanField('是否 部署/回滚 完成', default=False)
    remark = models.CharField('说明', max_length=500, blank=True)
    server_type = models.CharField('服务类型', max_length=100, blank=True, editable=False)
    bak_file = models.CharField('历史版本备份地址', max_length=500, blank=True, editable=False)

    def __str__(self):
        return ''

    class Meta:
        verbose_name_plural = verbose_name = "部署情况明细"
