import os
from deployment.deploy import DeployServer
from deployment.models import DeployMainTable
from deployment.models import DeploySubTable
from server_data.models import AppList


# 部署汇总函数
def to_deploy_server(deploy_id):
    need_deploy_server_list = DeploySubTable.objects.values().filter(deploy_sub_table_id=deploy_id)
    if len(need_deploy_server_list) == 0:
        to_first_deploy_server(deploy_id)
    else:
        to_second_deploy_server(deploy_id)


# 一次全部部署服务
def to_first_deploy_server(deploy_id):
    """

    :param deploy_id:
    :return:
    """
    # 获取要操作的应用、操作类型以及上传过来的文件
    deploy_app_type_file = DeployMainTable.objects.values('deploy_app',
                                                          'deploy_type',
                                                          'deploy_file').filter(deploy_id=deploy_id)[0]
    deploy_app = deploy_app_type_file['deploy_app']
    deploy_file = deploy_app_type_file['deploy_file']
    # 获取服务类型、服务目录、备份目录以及服务器
    app = AppList.objects.get(app_id=deploy_app)

    app_type = app.app_type.server_type
    app_directory = app.app_directory
    app_bak_directory = app.app_bak_directory

    # 需要部署的服务器列表
    need_deploy_server_list = app.app_servers.all()

    all_deploy_status = []
    for need_deploy_server in need_deploy_server_list:
        # 部署是否完成初始值为 False
        deploy_status = False
        # 历史版本备份路径初始值为空
        bak_file = ''

        # 获取对应服务用户名 密码 等等相关信息
        server_name = need_deploy_server.server_name
        server_ip = need_deploy_server.server_ip
        server_port = need_deploy_server.server_port
        server_user = need_deploy_server.server_user
        server_password = need_deploy_server.server_password

        if app_type == 'web服务器':
            try:
                upload_file_name = deploy_file[deploy_file.rfind('/') + 1:]
                deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                remark, bak_file = deploy_server.deploy_web_server(app_directory, app_bak_directory, deploy_file,
                                                                   upload_file_name)
                if remark == '部署完成':
                    deploy_status = True
            except:
                remark = '未知错误'
            finally:
                deploy_main_table = DeployMainTable.objects.get(deploy_id=deploy_id)
                DeploySubTable.objects.create(deploy_sub_table_id=deploy_main_table,
                                              server_name=server_name,
                                              server_ip=server_ip,
                                              server_port=server_port,
                                              server_user=server_user,
                                              server_password=server_password,
                                              server_directory=app_directory,
                                              server_bak_directory=app_bak_directory,
                                              status=deploy_status,
                                              remark=remark,
                                              server_type=str(app_type),
                                              bak_file=bak_file
                                              )
                all_deploy_status.append(deploy_status)

        elif app_type == 'service服务器':
            try:
                upload_file_name = deploy_file[deploy_file.rfind('/') + 1:]
                deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                remark, bak_file = deploy_server.deploy_service_server(app_directory, app_bak_directory, deploy_file,
                                                                       upload_file_name)
                if remark == '部署完成':
                    deploy_status = True
            except:
                remark = '未知错误'
            finally:
                deploy_main_table = DeployMainTable.objects.get(deploy_id=deploy_id)
                DeploySubTable.objects.create(deploy_sub_table_id=deploy_main_table,
                                              server_name=server_name,
                                              server_ip=server_ip,
                                              server_port=server_port,
                                              server_user=server_user,
                                              server_password=server_password,
                                              server_directory=app_directory,
                                              server_bak_directory=app_bak_directory,
                                              status=deploy_status,
                                              remark=remark,
                                              server_type=str(app_type),
                                              bak_file=bak_file
                                              )
                all_deploy_status.append(deploy_status)

    # 本地不保留上传文件
    if all(all_deploy_status):
        DeployMainTable.objects.filter(deploy_id=deploy_id).update(deploy_file='')
        # 删除文件
        os.remove(deploy_file)
        # 删除文件夹
        index = deploy_file.rfind('/')
        os.rmdir(deploy_file[0:index])


# 二次部分部署
def to_second_deploy_server(deploy_id):
    """

    :param deploy_id:
    :return:
    """
    deploy_app_type_file = DeployMainTable.objects.values('deploy_file').filter(deploy_id=deploy_id)[0]
    deploy_file = deploy_app_type_file['deploy_file']
    # 获取二次需要部署的服务器
    need_deploy_server_list = DeploySubTable.objects.values().filter(deploy_sub_table_id=deploy_id, status=False)

    all_deploy_status = []
    for need_deploy_server in need_deploy_server_list:
        # 部署是否完成初始值为 False
        deploy_status = False

        # 获取对应服务用户名 密码 等等相关信息
        table_id = need_deploy_server['id']
        server_ip = need_deploy_server['server_ip']
        server_port = int(need_deploy_server['server_port'])
        server_user = need_deploy_server['server_user']
        server_password = need_deploy_server['server_password']
        server_directory = need_deploy_server['server_directory']
        server_bak_directory = need_deploy_server['server_bak_directory']
        server_type = need_deploy_server['server_type']
        bak_file = need_deploy_server['bak_file']

        if server_type == 'web服务器':
            try:
                if bak_file == '':
                    upload_file_name = deploy_file[deploy_file.rfind('/') + 1:]
                    deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                    remark, bak_file = deploy_server.deploy_web_server(server_directory, server_bak_directory,
                                                                       deploy_file,
                                                                       upload_file_name)
                    if remark == '部署完成':
                        deploy_status = True

                else:
                    upload_file_name = deploy_file[deploy_file.rfind('/') + 1:]
                    deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                    remark, temp = deploy_server.deploy_web_server(server_directory, '',
                                                                   deploy_file,
                                                                   upload_file_name)
                    if remark == '部署完成':
                        deploy_status = True
            except:
                remark = '未知错误'
            finally:
                DeploySubTable.objects.filter(id=table_id).update(remark=remark,
                                                                  status=deploy_status,
                                                                  bak_file=bak_file)
                all_deploy_status.append(deploy_status)

        elif server_type == 'service服务器':
            try:
                if bak_file == '':
                    upload_file_name = deploy_file[deploy_file.rfind('/') + 1:]
                    deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                    remark, bak_file = deploy_server.deploy_service_server(server_directory, server_bak_directory,
                                                                           deploy_file,
                                                                           upload_file_name)
                    if remark == '部署完成':
                        deploy_status = True

                else:
                    upload_file_name = deploy_file[deploy_file.rfind('/') + 1:]
                    deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                    remark, temp = deploy_server.deploy_service_server(server_directory, '',
                                                                       deploy_file,
                                                                       upload_file_name)
                    if remark == '部署完成':
                        deploy_status = True

            except:
                remark = '未知错误'
            finally:
                DeploySubTable.objects.filter(id=table_id).update(remark=remark,
                                                                  status=deploy_status,
                                                                  bak_file=bak_file)
                all_deploy_status.append(deploy_status)

    # 本地不保留上传文件
    if all(all_deploy_status):
        DeployMainTable.objects.filter(deploy_id=deploy_id).update(deploy_file='')
        os.remove(deploy_file)


# 回滚
def to_rollback_server(deploy_id):
    """

    :param deploy_id:
    :return:
    """
    # 获取需要部署的全部服务id列表
    need_rollback_server_list = DeploySubTable.objects.values().filter(deploy_sub_table_id=deploy_id, status=False)
    for need_rollback_server in need_rollback_server_list:
        rollback_status = False
        # 获取此条记录的id 便于后面修改值
        table_id = need_rollback_server['id']
        # 获取历史版本备份地址
        bak_file = need_rollback_server['bak_file']

        server_ip = need_rollback_server['server_ip']
        server_port = need_rollback_server['server_port']
        server_user = need_rollback_server['server_user']
        server_password = need_rollback_server['server_password']
        server_directory = need_rollback_server['server_directory']
        server_type = need_rollback_server['server_type']

        try:
            if server_type == 'web服务器':
                deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                remark = deploy_server.rollback_web_server(server_directory, bak_file)
                if remark == '回滚完成':
                    rollback_status = True
            elif server_type == 'service服务器':
                deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                remark = deploy_server.rollback_service_server(server_directory, bak_file)
                if remark == '回滚完成':
                    rollback_status = True
        except:
            remark = '未知错误'

        finally:
            DeploySubTable.objects.filter(id=table_id).update(remark=remark, status=rollback_status)
