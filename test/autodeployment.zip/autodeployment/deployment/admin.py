import json
from urllib.parse import quote as urlquote
from django.contrib import messages
from django.contrib.admin.templatetags.admin_urls import add_preserved_filters
from django.contrib.admin.utils import quote
from django.http import HttpResponseRedirect
from django.template.response import TemplateResponse
from django.urls import reverse
from django.utils.html import format_html
from django.contrib import admin
from deployment.models import *
from deployment.deploy_server import to_deploy_server
from deployment.deploy_server import to_rollback_server

IS_POPUP_VAR = '_popup'
TO_FIELD_VAR = '_to_field'

HORIZONTAL, VERTICAL = 1, 2


# Register your models here.
class SubInlineDeploySubTable(admin.TabularInline):
    model = DeploySubTable
    extra = 0
    fields = ('server_name', 'server_ip', 'server_port',
              'server_directory', 'server_bak_directory',
              'status', 'remark')
    readonly_fields = ('server_name', 'server_ip', 'server_port',
                       'server_directory', 'server_bak_directory',
                       'remark')


@admin.register(DeployMainTable)
class ServerDeployMainTable(admin.ModelAdmin):
    inlines = [SubInlineDeploySubTable, ]
    raw_id_fields = ('deploy_app',)
    fields = (('deploy_date', 'deploy_type'), 'deploy_app', 'deploy_version', 'deploy_file', 'remark')
    radio_fields = {'deploy_type': admin.HORIZONTAL}
    list_display = ('deploy_date', 'deploy_app', 'deploy_version', 'deploy_type', 'remark',)
    list_filter = ('deploy_app', 'deploy_type')
    search_fields = ('remark',)
    ordering = ('-deploy_date',)
    list_per_page = 50

    def save_model(self, request, obj, form, change):
        # 获取当前时间
        if change:
            # obj_original = self.model.objects.get(pk=obj.pk)
            obj.LastUpdateUser = request.user.first_name

        else:
            # messages.error(request, 'Hello world.')
            # obj_original = None
            obj.Creator = request.user.first_name
            obj.LastUpdateUser = request.user.first_name
        obj.save()

    def response_add(self, request, obj, post_url_continue=None):
        """
        Determine the HttpResponse for the add_view stage.
        """
        opts = obj._meta
        preserved_filters = self.get_preserved_filters(request)
        obj_url = reverse(
            'admin:%s_%s_change' % (opts.app_label, opts.model_name),
            args=(quote(obj.pk),),
            current_app=self.admin_site.name,
        )
        # Add a link to the object's change form if the user can edit the obj.
        if self.has_change_permission(request, obj):
            obj_repr = format_html('<a href="{}">{}</a>', urlquote(obj_url), obj)
        else:
            obj_repr = str(obj)
        msg_dict = {
            'name': opts.verbose_name,
            'obj': obj_repr,
        }
        # Here, we distinguish between different save types by checking for
        # the presence of keys in request.POST.

        if "_continue" in request.POST or (
                # Redirecting after "Save as new".
                "_saveasnew" in request.POST and self.save_as_continue and
                self.has_change_permission(request, obj)
        ):
            msg = 'The {name} "{obj}" was added successfully.'
            if self.has_change_permission(request, obj):
                msg = ''
            self.message_user(request, format_html(msg, **msg_dict), messages.SUCCESS)
            if post_url_continue is None:
                post_url_continue = obj_url
            post_url_continue = add_preserved_filters(
                {'preserved_filters': preserved_filters, 'opts': opts},
                post_url_continue
            )
            # TODO 改写这个位置
            # 运行部署函数
            if obj.deploy_type == '部署':
                to_deploy_server(obj.deploy_id)
            else:
                to_rollback_server(obj.deploy_id)

            return HttpResponseRedirect(post_url_continue)

    def response_change(self, request, obj):
        """
        Determine the HttpResponse for the change_view stage.
        """

        if IS_POPUP_VAR in request.POST:
            opts = obj._meta
            to_field = request.POST.get(TO_FIELD_VAR)
            attr = str(to_field) if to_field else opts.pk.attname
            value = request.resolver_match.kwargs['object_id']
            new_value = obj.serializable_value(attr)
            popup_response_data = json.dumps({
                'action': 'change',
                'value': str(value),
                'obj': str(obj),
                'new_value': str(new_value),
            })
            return TemplateResponse(request, self.popup_response_template or [
                'admin/%s/%s/popup_response.html' % (opts.app_label, opts.model_name),
                'admin/%s/popup_response.html' % opts.app_label,
                'admin/popup_response.html',
            ], {
                                        'popup_response_data': popup_response_data,
                                    })

        opts = self.model._meta
        preserved_filters = self.get_preserved_filters(request)

        if "_continue" in request.POST:
            msg = format_html(
                ''
            )
            self.message_user(request, msg, messages.SUCCESS)
            redirect_url = request.path
            redirect_url = add_preserved_filters({'preserved_filters': preserved_filters, 'opts': opts}, redirect_url)
            # TODO 改写这个位置
            if obj.deploy_type == '部署':
                to_deploy_server(obj.deploy_id)
            else:
                to_rollback_server(obj.deploy_id)

            return HttpResponseRedirect(redirect_url)
