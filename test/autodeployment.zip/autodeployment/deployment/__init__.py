default_app_config = 'deployment.apps.DeploymentConfig'
