from django.db import models
from cryptography.fernet import Fernet


class AesField(models.CharField):
    """
    model Fields for aes
    """

    _KEY = 'cP5rpi0gwA9oaZyhddVvrO9Q4fgnD_-j623rK2o6UEI='

    def encrypt(self, value):
        fer = Fernet(self._KEY)
        value = value.encode()
        token = fer.encrypt(value)
        encrypt_value = token.decode()
        return encrypt_value

    def decrypt(self, value):
        fer = Fernet(self._KEY)
        value = value.encode()
        token = fer.decrypt(value)
        decrypt_value = token.decode()
        return decrypt_value

    def get_prep_value(self, value):
        value = super().get_prep_value(value)
        value = self.encrypt(value)
        return self.to_python(value)

    def from_db_value(self, value, expression, connection, context):
        if not value:
            return value
        return self.decrypt(value)
