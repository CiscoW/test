from django.contrib import admin
from server_data.models import *
from server_data.forms import ServerListForm

_COLORED_SERVICE_STATUS = {
    "正常": "green",
    "异常": "red",
    "未知": "orange",

}


# Register your models here.

@admin.register(BaseServerData)
class ServerBaseServerData(admin.ModelAdmin):
    list_display = ('server_type', 'status', 'remark')
    list_per_page = 50


@admin.register(ServerList)
class ServerServerList(admin.ModelAdmin):
    form = ServerListForm
    list_display = ('server_name',
                    'server_ip', 'server_port',
                    'server_user',
                    'status', 'remark',
                    )
    list_filter = ('status',)
    search_fields = ('server_name', 'server_ip',)
    ordering = ('-LastUpdateTime',)
    list_per_page = 50

    def save_model(self, request, obj, form, change):
        if change:
            obj.LastUpdateUser = request.user.first_name
        else:
            obj.Creator = request.user.first_name
            obj.LastUpdateUser = request.user.first_name

        obj.save()


@admin.register(AppList)
class ServerAppList(admin.ModelAdmin):
    list_display = ('app_name', 'app_type', 'app_directory', 'app_bak_directory', 'status', 'remark')
    list_filter = ('app_type', 'status')
    search_fields = ('app_name', 'remark',)
    fields = (('app_name', 'app_type'), 'app_servers', ('app_directory', 'app_bak_directory'), 'status', 'remark')
    filter_horizontal = ('app_servers',)
    ordering = ('-LastUpdateTime',)
    list_per_page = 50

    def save_model(self, request, obj, form, change):
        if change:
            # obj_original = self.model.objects.get(pk=obj.pk)
            obj.LastUpdateUser = request.user.first_name

        else:
            # obj_original = None
            obj.Creator = request.user.first_name
            obj.LastUpdateUser = request.user.first_name

        obj.save()
