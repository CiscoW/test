from django import forms
from server_data.models import ServerList


class ServerListForm(forms.ModelForm):
    server_password = forms.CharField(label='密码', widget=forms.PasswordInput)

    class Meta:
        model = ServerList
        fields = "__all__"
