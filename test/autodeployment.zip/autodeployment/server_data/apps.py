from django.apps import AppConfig


class ServerDataConfig(AppConfig):
    name = 'server_data'
    verbose_name = "基础数据"

