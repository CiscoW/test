import uuid

from django.db import models

from server_data.AES import AesField


# 去掉连接符

def get_uuid1():
    return str(uuid.uuid1()).replace('-', '')


# Create your models here.

# 服务类型基础表 暂时只有web服务和service服务

class BaseServerData(models.Model):
    server_type = models.CharField('服务类型', max_length=100, primary_key=True)
    status = models.BooleanField('是否启用', default=True)
    remark = models.TextField('备注', blank=True)

    #
    Creator = models.CharField(u'创建者', max_length=100, editable=False, blank=True)
    CreateTime = models.DateTimeField(u'创建时间', auto_now_add=True, editable=False, blank=True)
    LastUpdateUser = models.CharField(u'最后修改者', max_length=100, editable=False, blank=True)
    LastUpdateTime = models.DateTimeField(u'最后修改时间', auto_now=True, editable=False, blank=True)

    def __str__(self):
        return self.server_type

    class Meta:
        verbose_name_plural = verbose_name = "服务类型"


# 服务器列表

class ServerList(models.Model):
    server_id = models.CharField('id', max_length=32, primary_key=True, default=get_uuid1, editable=False)
    server_name = models.CharField('服务器 名称', max_length=100)
    server_ip = models.GenericIPAddressField('IP地址', default='10.1.16.1')
    server_port = models.IntegerField(u'端口', default=22)
    server_user = AesField('用户名', max_length=500, default='root')
    server_password = AesField('密码', max_length=500)
    status = models.BooleanField('是否启用', default=True)
    remark = models.TextField('备注', blank=True)

    Creator = models.CharField(u'创建者', max_length=100, editable=False, blank=True)
    CreateTime = models.DateTimeField(u'创建时间', auto_now_add=True, editable=False, blank=True)
    LastUpdateUser = models.CharField(u'最后修改者', max_length=100, editable=False, blank=True)
    LastUpdateTime = models.DateTimeField(u'最后修改时间', auto_now=True, editable=False, blank=True)

    def __str__(self):
        return self.server_name

    class Meta:
        verbose_name_plural = verbose_name = "服务器列表"


# 应用列表

class AppList(models.Model):
    app_id = models.CharField('id', max_length=32, primary_key=True, default=get_uuid1, editable=False)
    app_name = models.CharField('应用 名称', max_length=100)
    app_type = models.ForeignKey(BaseServerData, verbose_name='服务类型', limit_choices_to={'status': True},
                                 on_delete=models.PROTECT)
    app_servers = models.ManyToManyField(ServerList, verbose_name='部署服务器', limit_choices_to={'status': True})
    app_directory = models.CharField('服务目录', max_length=100)
    app_bak_directory = models.CharField('备份目录', max_length=100)
    status = models.BooleanField('是否启用', default=True)
    remark = models.TextField('备注', blank=True)

    Creator = models.CharField(u'创建者', max_length=100, editable=False, blank=True)
    CreateTime = models.DateTimeField(u'创建时间', auto_now_add=True, editable=False, blank=True)
    LastUpdateUser = models.CharField(u'最后修改者', max_length=100, editable=False, blank=True)
    LastUpdateTime = models.DateTimeField(u'最后修改时间', auto_now=True, editable=False, blank=True)

    def __str__(self):
        return self.app_name

    class Meta:
        verbose_name_plural = verbose_name = "应用列表"
