from django.apps import AppConfig


class SyntheticDataConfig(AppConfig):
    name = 'synthetic_data'
    verbose_name = "监控数据"
