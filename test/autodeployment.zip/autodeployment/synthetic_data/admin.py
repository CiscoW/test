from django.contrib import admin
from synthetic_data.models import AppStateMainTable
from synthetic_data.models import AppStateServerSubTable
from synthetic_data.models import AppStateVersionSubTable
from synthetic_data.models import ServerStateMainTable
from synthetic_data.models import ServerStateSubTable
from django.utils.html import format_html


# Register your models here.


class SubInlineAppStateServerSubTable(admin.TabularInline):
    model = AppStateServerSubTable
    extra = 0
    fields = ('server_name', 'server_ip', 'server_port', 'server_status', 'service_status')
    readonly_fields = ('server_name', 'server_ip', 'server_port', 'server_status', 'service_status')


class SubInlineAppStateVersionSubTable(admin.TabularInline):
    model = AppStateVersionSubTable
    extra = 0
    fields = ('deploy_date', 'deploy_version', 'deploy_remark')
    readonly_fields = ('deploy_date', 'deploy_version', 'deploy_remark')


@admin.register(AppStateMainTable)
class ServerAppStateMainTable(admin.ModelAdmin):
    inlines = [SubInlineAppStateServerSubTable, SubInlineAppStateVersionSubTable]
    fields = (
        ('app_name', 'app_type', 'app_version', 'app_version_num'),
        ('app_server_normal_num', 'app_server_abnormal_num'),
        ('app_directory', 'app_bak_directory'),
        'app_status'
    )

    list_display = ('update_time',
                    'app_name', 'app_type',
                    'server_num', 'colored_app_server_normal_num', 'colored_app_server_abnormal_num',
                    'app_version', 'app_version_num',
                    'app_directory', 'app_bak_directory',
                    'app_status',
                    )
    list_filter = ('app_type', 'app_status')
    search_fields = ('app_name',)
    ordering = ('-update_time',)
    list_per_page = 50

    def get_queryset(self, request):
        """函数作用：只能看见可显示的内容"""
        qs = super(ServerAppStateMainTable, self).get_queryset(request)
        return qs.filter(show=True)

    def colored_app_server_normal_num(self, obj):
        return format_html('<span style="color: {};">{}</span>', 'green', obj.app_server_normal_num)

    colored_app_server_normal_num.short_description = "服务-正常"

    def colored_app_server_abnormal_num(self, obj):
        if obj.app_server_abnormal_num > 0:
            return format_html('<span style="color: {};">{}</span>', 'red', obj.app_server_abnormal_num)
        return format_html('<span style="color: {};">{}</span>', 'green', obj.app_server_abnormal_num)

    colored_app_server_abnormal_num.short_description = "服务-异常"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


class SubInlineServerStateSubTable(admin.TabularInline):
    model = ServerStateSubTable
    extra = 0
    fields = ('app_name', 'app_directory', 'app_bak_directory', 'app_status', 'service_status', 'app_last_deploy_time')
    readonly_fields = ('app_name', 'app_directory', 'app_bak_directory',
                       'app_status', 'service_status', 'app_last_deploy_time'
                       )


@admin.register(ServerStateMainTable)
class ServerServerStateMainTable(admin.ModelAdmin):
    inlines = [SubInlineServerStateSubTable, ]
    fields = (('server_name', 'server_ip', 'server_port'),
              ('deploy_app_num', 'app_normal_num', 'app_abnormal_num'),
              'server_status',
              )
    list_display = ('update_time', 'server_name', 'server_ip', 'server_port',
                    'deploy_app_num', 'colored_app_normal_num', 'colored_app_abnormal_num'
                    )
    search_fields = ('server_name', 'server_ip')
    ordering = ('-update_time',)
    list_per_page = 50

    def get_queryset(self, request):
        """函数作用：只能看见可显示的内容"""
        qs = super(ServerServerStateMainTable, self).get_queryset(request)
        return qs.filter(show=True)

    def colored_app_normal_num(self, obj):
        return format_html('<span style="color: {};">{}</span>', 'green', obj.app_normal_num)

    colored_app_normal_num.short_description = "服务-正常"

    def colored_app_abnormal_num(self, obj):
        if obj.app_abnormal_num > 0:
            return format_html('<span style="color: {};">{}</span>', 'red', obj.app_abnormal_num)
        return format_html('<span style="color: {};">{}</span>', 'green', obj.app_abnormal_num)

    colored_app_abnormal_num.short_description = "服务-异常"

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False
