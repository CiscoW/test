import datetime
import time
import uuid
from django.db.models import Max
from server_data.models import AppList
from server_data.models import ServerList
from deployment.models import DeployMainTable
from synthetic_data.models import AppStateMainTable
from synthetic_data.models import AppStateServerSubTable
from synthetic_data.models import AppStateVersionSubTable
from synthetic_data.models import ServerStateMainTable
from synthetic_data.models import ServerStateSubTable
from deployment.deploy_server import DeployServer
from django.db.utils import OperationalError


class AppState(object):

    def __init__(self):
        self.app_id = ''
        self.app_servers = []
        self.app_directory = ''
        self.app_type = ''
        self.update_tag = str(uuid.uuid1()).replace('-', '')

    def get_app_data(self):
        """

        :return:
        """
        app_list = AppList.objects.filter(status=True)
        for app in app_list:
            self.app_id = app.app_id
            app_name = app.app_name
            self.app_type = app.app_type
            self.app_servers = app.app_servers.all()
            self.app_directory = app.app_directory
            app_bak_directory = app.app_bak_directory
            app_status = app.status
            app_remark = app.remark
            yield (self.app_id, app_name, self.app_type,
                   self.app_directory, app_bak_directory, app_status, app_remark)

    def get_server_data(self):
        server_num = 0
        app_server_normal_num = 0
        app_server_abnormal_num = 0
        service_status = '正常'
        for app_server in self.app_servers:
            server_id = app_server.server_id
            server_name = app_server.server_name
            server_ip = app_server.server_ip
            server_port = app_server.server_port
            server_user = app_server.server_user
            server_password = app_server.server_password
            server_status = app_server.status
            # TODO service_status 此处需要连接服务器
            if server_status:
                server_num += 1
                try:
                    deploy_server = DeployServer(server_ip, server_port, server_user, server_password)
                    deploy_server.connect_ssh_client()
                    if str(self.app_type) == 'web服务器':
                        pid_list = deploy_server.get_pid_list('nginx')
                        if len(pid_list) != 0:
                            app_server_normal_num += 1
                            service_status = '正常'
                        else:
                            app_server_abnormal_num += 1
                            service_status = '异常'
                    elif str(self.app_type) == 'service服务器':
                        file_list = deploy_server.get_file_list(self.app_directory)
                        for file in file_list:
                            if file[file.rfind('.') + 1:] == 'jar':
                                pid_list = deploy_server.get_pid_list(file)
                                if len(pid_list) != 0:
                                    app_server_normal_num += 1
                                    service_status = '正常'
                                else:
                                    app_server_abnormal_num += 1
                                    service_status = '异常'
                                    if 'deploying' not in file_list:
                                        deploy_server.execute_sh_file(self.app_directory, 'run.sh')

                except Exception:
                    app_server_abnormal_num += 1
                    service_status = '异常'
            else:
                continue

            yield (server_id, server_name, server_ip, server_port, server_status,
                   server_num, app_server_normal_num, app_server_abnormal_num, service_status)

    def get_app_version_data(self):
        # TODO 此处紧是获取最新版本，未必是部署版本，后续需要根据使用情况看实际部署版本的获取方式
        app_versions = DeployMainTable.objects.filter(deploy_app_id=self.app_id)
        app_version_num = len(app_versions)
        app_last_version = ''
        for app_version in app_versions:
            if app_last_version == '':
                deploy_date = app_version.deploy_date
                last_update_time = app_version.LastUpdateTime
                app_last_version = app_version.deploy_version
            elif deploy_date < app_version.deploy_date:
                app_last_version = app_version.deploy_version
            elif deploy_date == app_version.deploy_date and last_update_time < app_version.LastUpdateTime:
                app_last_version = app_version.deploy_version

            yield (app_version.deploy_date, app_version.deploy_version, app_version.remark,
                   app_version_num, app_last_version)

    def update_app_state(self):
        server_num = 0
        app_server_normal_num = 0
        app_server_abnormal_num = 0
        app_last_version = '暂未部署'
        app_version_num = 0

        for app_data in self.get_app_data():
            (app_id, app_name, app_type,
             app_directory, app_bak_directory, app_status, app_remark) = app_data
            try:
                app_state_main_table = AppStateMainTable.objects.get(app_id=app_id)
            except Exception:
                AppStateMainTable.objects.create(app_id=app_id, app_status=app_status)
                app_state_main_table = AppStateMainTable.objects.get(app_id=app_id)

            for server_data in self.get_server_data():
                (server_id, server_name, server_ip, server_port, server_status,
                 server_num, app_server_normal_num, app_server_abnormal_num, service_status) = server_data
                if len(AppStateServerSubTable.objects.filter(app_id=app_state_main_table, server_id=server_id)) != 0:
                    AppStateServerSubTable.objects.filter(app_id=app_state_main_table, server_id=server_id).update(
                        app_id=app_state_main_table,
                        server_id=server_id,
                        server_name=server_name,
                        server_ip=server_ip,
                        server_port=server_port,
                        server_status=server_status,
                        service_status=service_status,
                        update_tag=self.update_tag
                    )
                else:
                    AppStateServerSubTable.objects.create(
                        app_id=app_state_main_table,
                        server_id=server_id,
                        server_name=server_name,
                        server_ip=server_ip,
                        server_port=server_port,
                        server_status=server_status,
                        service_status=service_status,
                        update_tag=self.update_tag

                    )
            AppStateServerSubTable.objects.exclude(update_tag=self.update_tag).delete()

            for app_version_data in self.get_app_version_data():
                (deploy_date, deploy_version, remark,
                 app_version_num, app_last_version) = app_version_data

                if len(AppStateVersionSubTable.objects.filter(app_id=app_state_main_table,
                                                              deploy_version=deploy_version)) != 0:
                    AppStateVersionSubTable.objects.filter(app_id=app_state_main_table,
                                                           deploy_version=deploy_version).update(
                        deploy_date=deploy_date,
                        deploy_version=deploy_version,
                        deploy_remark=remark,
                        update_tag=self.update_tag

                    )
                else:
                    AppStateVersionSubTable.objects.create(
                        app_id=app_state_main_table,
                        deploy_date=deploy_date,
                        deploy_version=deploy_version,
                        deploy_remark=remark,
                        update_tag=self.update_tag

                    )
            AppStateVersionSubTable.objects.exclude(update_tag=self.update_tag).delete()

            AppStateMainTable.objects.filter(app_id=app_id).update(
                app_id=app_id,
                update_time=datetime.datetime.now(),
                app_name=app_name,
                app_type=str(app_type),
                server_num=server_num,
                app_server_normal_num=app_server_normal_num,
                app_server_abnormal_num=app_server_abnormal_num,
                app_version=app_last_version,
                app_version_num=app_version_num,
                app_status=app_status,
                app_directory=app_directory,
                app_bak_directory=app_bak_directory,
                app_remark=app_remark,
                update_tag=self.update_tag,
                show=True

            )
        AppStateMainTable.objects.exclude(update_tag=self.update_tag).update(show=False)


class ServerState(object):

    def __init__(self):
        self.server_id = ''
        self.server_user = ''
        self.server_password = ''
        self.server_ip = ''
        self.server_port = ''
        self.update_tag = str(uuid.uuid1()).replace('-', '')

    def get_server_data(self):
        server_list = ServerList.objects.filter(status=True)
        for server in server_list:
            self.server_id = server.server_id
            server_name = server.server_name
            self.server_ip = server.server_ip
            self.server_port = server.server_port
            self.server_user = server.server_user
            self.server_password = server.server_password
            server_status = server.status
            server_remark = server.remark
            yield (self.server_id, server_name, self.server_ip, self.server_port, server_status, server_remark)

    def get_app_data(self):
        app_list = AppList.objects.filter(app_servers=self.server_id)
        deploy_app_num = 0
        app_normal_num = 0
        app_abnormal_num = 0
        service_status = '正常'

        for app in app_list:
            app_id = app.app_id
            app_name = app.app_name
            app_type = app.app_type
            app_directory = app.app_directory
            app_bak_directory = app.app_bak_directory
            app_status = app.status
            # TODO service_status 此处需要连接服务器
            if app_status:
                deploy_app_num += 1
                try:
                    deploy_server = DeployServer(self.server_ip, self.server_port, self.server_user,
                                                 self.server_password)
                    deploy_server.connect_ssh_client()
                    if str(app_type) == 'web服务器':
                        pid_list = deploy_server.get_pid_list('nginx')
                        if len(pid_list) != 0:
                            app_normal_num += 1
                            service_status = '正常'
                        else:
                            app_abnormal_num += 1
                            service_status = '异常'
                    elif str(app_type) == 'service服务器':
                        file_list = deploy_server.get_file_list(app_directory)
                        for file in file_list:
                            if file[file.rfind('.') + 1:] == 'jar':
                                pid_list = deploy_server.get_pid_list(file)
                                if len(pid_list) != 0:
                                    app_normal_num += 1
                                    service_status = '正常'
                                else:
                                    app_abnormal_num += 1
                                    service_status = '异常'

                except Exception:
                    app_abnormal_num += 1
                    service_status = '异常'
            else:
                continue

            app_last_deploy_time = DeployMainTable.objects.filter(deploy_app=app_id
                                                                  ).aggregate(Max('deploy_date'))['deploy_date__max']
            if app_last_deploy_time is None:
                app_last_deploy_time = '暂未部署'

            yield (app_id, app_name,
                   app_directory, app_bak_directory, app_status, str(app_last_deploy_time),
                   deploy_app_num, app_normal_num, app_abnormal_num, service_status)

    def update_server_state(self):
        for server_data in self.get_server_data():
            deploy_app_num = 0
            app_normal_num = 0
            app_abnormal_num = 0
            (server_id, server_name, server_ip, server_port, server_status, server_remark) = server_data
            try:
                server_state_main_table = ServerStateMainTable.objects.get(server_id=server_id)
            except Exception:
                ServerStateMainTable.objects.create(server_id=server_id, server_status=server_status)
                server_state_main_table = ServerStateMainTable.objects.get(server_id=server_id)

            for app_data in self.get_app_data():
                (app_id, app_name, app_directory, app_bak_directory, app_status, app_last_deploy_time,
                 deploy_app_num, app_normal_num, app_abnormal_num, service_status) = app_data
                if len(ServerStateSubTable.objects.filter(app_id=app_id)) != 0:
                    ServerStateSubTable.objects.filter(app_id=app_id).update(
                        server_id=server_state_main_table,
                        app_id=app_id,
                        app_name=app_name,
                        app_directory=app_directory,
                        app_bak_directory=app_bak_directory,
                        app_status=app_status,
                        service_status=service_status,
                        app_last_deploy_time=app_last_deploy_time,
                        update_tag=self.update_tag

                    )
                else:
                    ServerStateSubTable.objects.create(
                        server_id=server_state_main_table,
                        app_id=app_id,
                        app_name=app_name,
                        app_directory=app_directory,
                        app_bak_directory=app_bak_directory,
                        app_status=app_status,
                        service_status=service_status,
                        app_last_deploy_time=app_last_deploy_time,
                        update_tag=self.update_tag

                    )
            ServerStateSubTable.objects.exclude(update_tag=self.update_tag).delete()

            ServerStateMainTable.objects.filter(server_id=server_id).update(
                server_id=server_id,
                update_time=datetime.datetime.now(),
                server_name=server_name,
                server_ip=server_ip,
                server_port=server_port,
                server_status=server_status,
                deploy_app_num=deploy_app_num,
                app_normal_num=app_normal_num,
                app_abnormal_num=app_abnormal_num,
                server_remark=server_remark,
                update_tag=self.update_tag,
                show=True
            )
        ServerStateMainTable.objects.exclude(update_tag=self.update_tag).update(show=False)


def main():
    while True:
        try:
            # 应用监控
            app_state = AppState()
            app_state.update_app_state()
            # 服务器监控
            server_state = ServerState()
            server_state.update_server_state()
        except OperationalError:
            # sqlite3 数据库锁的问题
            pass
        finally:
            time.sleep(60)
