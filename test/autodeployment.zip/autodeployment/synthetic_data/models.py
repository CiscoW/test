from django.db import models

STATUS = (
    ('正常', '正常'),
    ('异常', '异常'),
)


# Create your models here.
class AppStateMainTable(models.Model):
    app_id = models.CharField('id', max_length=100, primary_key=True)
    update_time = models.DateTimeField('更新时间', auto_now=True)
    app_name = models.CharField('应用名称', max_length=100, blank=True)
    app_type = models.CharField('服务类型', max_length=100, blank=True)
    server_num = models.IntegerField('服务器数', blank=True, null=True)
    app_server_normal_num = models.IntegerField('服务-正常', blank=True, null=True)
    app_server_abnormal_num = models.IntegerField('服务-异常', blank=True, null=True)
    app_version = models.CharField('最新版本号', max_length=100, blank=True)
    app_version_num = models.IntegerField('历史版本数', blank=True, null=True)
    app_status = models.BooleanField('是否启用', blank=True)
    app_directory = models.CharField('服务目录', max_length=100, blank=True)
    app_bak_directory = models.CharField('备份目录', max_length=100, blank=True)
    app_remark = models.TextField('备注', blank=True)
    update_tag = models.CharField('标记位', max_length=100, help_text='用于筛选是否这条记录是否显示', blank=True)
    show = models.BooleanField('是否显示', default=True)

    def __str__(self):
        return ''

    class Meta:
        verbose_name_plural = verbose_name = "应用监控"


class AppStateServerSubTable(models.Model):
    app_id = models.ForeignKey(AppStateMainTable, on_delete=models.CASCADE)
    server_id = models.CharField('服务器id', max_length=100)
    server_name = models.CharField('服务器 名称', max_length=100)
    server_ip = models.CharField('ip', max_length=100)
    server_port = models.IntegerField('端口')
    server_status = models.BooleanField('是否启用')
    service_status = models.CharField('服务状态', max_length=100)
    update_tag = models.CharField('标记位', max_length=100, help_text='用于筛选是否删除这条记录', blank=True)

    def __str__(self):
        return ''

    class Meta:
        verbose_name_plural = verbose_name = "部署服务器明细"


class AppStateVersionSubTable(models.Model):
    app_id = models.ForeignKey(AppStateMainTable, on_delete=models.CASCADE)
    deploy_date = models.DateField('部署日期')
    deploy_version = models.CharField('部署版本', max_length=100)
    deploy_remark = models.TextField('部署说明')
    update_tag = models.CharField('标记位', max_length=100, help_text='用于筛选是否删除这条记录', blank=True)

    def __str__(self):
        return ''

    class Meta:
        verbose_name_plural = verbose_name = "历史部署版本明细"


class ServerStateMainTable(models.Model):
    server_id = models.CharField('id', max_length=100)
    update_time = models.DateTimeField('更新时间', auto_now=True)
    server_name = models.CharField('服务器 名称', max_length=100, blank=True)
    server_ip = models.CharField('ip地址', max_length=100, blank=True)
    server_port = models.IntegerField('端口', blank=True, null=True)
    server_status = models.BooleanField('是否启用', blank=True)
    deploy_app_num = models.IntegerField('部署应用数', blank=True, null=True)
    app_normal_num = models.IntegerField('服务-正常', blank=True, null=True)
    app_abnormal_num = models.IntegerField('服务-异常', blank=True, null=True)
    server_remark = models.TextField('备注', blank=True)
    update_tag = models.CharField('标记位', max_length=100, help_text='用于筛选是否这条记录是否显示', blank=True)
    show = models.BooleanField('是否显示', default=True)

    def __str__(self):
        return ''

    class Meta:
        verbose_name_plural = verbose_name = "服务器监控"


class ServerStateSubTable(models.Model):
    server_id = models.ForeignKey(ServerStateMainTable, on_delete=models.CASCADE)
    app_id = models.CharField('应用id', max_length=100)
    app_name = models.CharField('应用 名称', max_length=100)
    app_directory = models.CharField('服务目录', max_length=100)
    app_bak_directory = models.CharField('备份目录', max_length=100)
    app_status = models.BooleanField('是否启用')
    service_status = models.CharField('服务状态', max_length=100, choices=STATUS)
    app_last_deploy_time = models.CharField('最后一次部署日期', max_length=100)
    update_tag = models.CharField('标记位', max_length=100, help_text='用于筛选是否删除这条记录', blank=True)

    def __str__(self):
        return ''

    class Meta:
        verbose_name_plural = verbose_name = "服务器部署应用明细"
