default_app_config = 'synthetic_data.apps.SyntheticDataConfig'
